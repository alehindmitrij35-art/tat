package dev.dirronlive.bridge;

import java.io.ByteArrayOutputStream;
import java.io.DataInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.InetAddress;
import java.net.ServerSocket;
import java.net.Socket;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.util.Base64;
import java.util.concurrent.BlockingQueue;
import java.util.concurrent.LinkedBlockingQueue;
import java.util.concurrent.TimeUnit;

/**
 * Минимальный WebSocket-сервер (RFC 6455) для тестов: играет роль
 * программы Dirronlive. Один клиент за раз, только текстовые кадры.
 */
final class TestWebSocketServer implements AutoCloseable {
    private static final String GUID = "258EAFA5-E914-47DA-95CA-C5AB0DC85B11";

    private final ServerSocket server;
    private final BlockingQueue<String> received = new LinkedBlockingQueue<>();
    private final BlockingQueue<Socket> accepted = new LinkedBlockingQueue<>();
    private volatile Socket client;
    private volatile int connections;

    TestWebSocketServer() throws IOException {
        this(0);
    }

    TestWebSocketServer(int port) throws IOException {
        server = new ServerSocket(port, 50, InetAddress.getLoopbackAddress());
        Thread acceptor = new Thread(this::acceptLoop, "test-ws-accept");
        acceptor.setDaemon(true);
        acceptor.start();
    }

    int port() {
        return server.getLocalPort();
    }

    int connections() {
        return connections;
    }

    /** Ждёт следующее текстовое сообщение от мода. */
    String next(long millis) throws InterruptedException {
        return received.poll(millis, TimeUnit.MILLISECONDS);
    }

    /** Ждёт следующее сообщение указанного типа, пропуская остальные. */
    String nextOfType(String type, long millis) throws InterruptedException {
        long deadline = System.currentTimeMillis() + millis;
        while (true) {
            long left = deadline - System.currentTimeMillis();
            if (left <= 0) return null;
            String message = received.poll(left, TimeUnit.MILLISECONDS);
            if (message == null) return null;
            if (type.equals(MiniJson.parseObject(message).get("type"))) return message;
        }
    }

    boolean awaitClient(long millis) throws InterruptedException {
        return accepted.poll(millis, TimeUnit.MILLISECONDS) != null;
    }

    synchronized void send(String text) throws IOException {
        Socket s = client;
        if (s == null) throw new IOException("нет клиента");
        byte[] payload = text.getBytes(StandardCharsets.UTF_8);
        OutputStream out = s.getOutputStream();
        out.write(0x81);
        if (payload.length < 126) {
            out.write(payload.length);
        } else {
            out.write(126);
            out.write((payload.length >> 8) & 0xff);
            out.write(payload.length & 0xff);
        }
        out.write(payload);
        out.flush();
    }

    /** Обрывает текущее соединение, как будто программу закрыли. */
    void dropClient() throws IOException {
        Socket s = client;
        client = null;
        if (s != null) s.close();
    }

    @Override
    public void close() throws IOException {
        dropClient();
        server.close();
    }

    private void acceptLoop() {
        while (!server.isClosed()) {
            try {
                Socket s = server.accept();
                handshake(s);
                client = s;
                connections++;
                accepted.add(s);
                Thread reader = new Thread(() -> readLoop(s), "test-ws-read");
                reader.setDaemon(true);
                reader.start();
            } catch (Exception e) {
                // Сервер закрыт или клиент сломался.
            }
        }
    }

    private static void handshake(Socket s) throws Exception {
        InputStream in = s.getInputStream();
        ByteArrayOutputStream head = new ByteArrayOutputStream();
        int matched = 0;
        while (matched < 4) {
            int b = in.read();
            if (b < 0) throw new IOException("клиент закрыл соединение");
            head.write(b);
            matched = (b == "\r\n\r\n".charAt(matched)) ? matched + 1 : (b == '\r' ? 1 : 0);
        }
        String key = null;
        for (String line : head.toString(StandardCharsets.ISO_8859_1).split("\r\n")) {
            int colon = line.indexOf(':');
            if (colon > 0 && line.substring(0, colon).trim().equalsIgnoreCase("Sec-WebSocket-Key")) {
                key = line.substring(colon + 1).trim();
            }
        }
        if (key == null) throw new IOException("нет Sec-WebSocket-Key");
        String accept = Base64.getEncoder().encodeToString(
                MessageDigest.getInstance("SHA-1").digest((key + GUID).getBytes(StandardCharsets.ISO_8859_1)));
        String response = "HTTP/1.1 101 Switching Protocols\r\n"
                + "Upgrade: websocket\r\nConnection: Upgrade\r\n"
                + "Sec-WebSocket-Accept: " + accept + "\r\n\r\n";
        s.getOutputStream().write(response.getBytes(StandardCharsets.ISO_8859_1));
        s.getOutputStream().flush();
    }

    private void readLoop(Socket s) {
        try {
            DataInputStream in = new DataInputStream(s.getInputStream());
            ByteArrayOutputStream message = new ByteArrayOutputStream();
            while (true) {
                int b0 = in.readUnsignedByte();
                int b1 = in.readUnsignedByte();
                boolean fin = (b0 & 0x80) != 0;
                int opcode = b0 & 0x0f;
                long length = b1 & 0x7f;
                if (length == 126) length = in.readUnsignedShort();
                else if (length == 127) length = in.readLong();
                byte[] mask = new byte[4];
                if ((b1 & 0x80) != 0) in.readFully(mask);
                byte[] data = new byte[(int) length];
                in.readFully(data);
                for (int i = 0; i < data.length; i++) data[i] ^= mask[i % 4];
                if (opcode == 0x8) { // close
                    s.close();
                    return;
                }
                if (opcode == 0x9 || opcode == 0xA) continue; // ping/pong
                message.write(data);
                if (fin) {
                    received.add(message.toString(StandardCharsets.UTF_8));
                    message.reset();
                }
            }
        } catch (IOException e) {
            // Соединение закрыто.
        }
    }
}

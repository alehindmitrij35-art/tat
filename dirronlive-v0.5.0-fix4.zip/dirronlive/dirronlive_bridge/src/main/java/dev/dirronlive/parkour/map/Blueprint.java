package dev.dirronlive.parkour.map;

import java.util.LinkedHashMap;
import java.util.Map;

/**
 * Чертёж: абсолютные координаты блока → строка блока Minecraft
 * («minecraft:cyan_concrete», «minecraft:furnace[lit=true]»).
 * Без классов Minecraft — проверяется обычными тестами.
 */
public final class Blueprint {
    private final Map<Long, String> blocks = new LinkedHashMap<>();

    public static long key(int x, int y, int z) {
        return ((long) (x & 0x3FFFFFF) << 38) | ((long) (z & 0x3FFFFFF) << 12) | (y & 0xFFF);
    }

    public static int keyX(long key) {
        return (int) (key >> 38) << 6 >> 6;
    }

    public static int keyZ(long key) {
        return (int) (key << 26 >> 38);
    }

    public static int keyY(long key) {
        return (int) (key << 52 >> 52);
    }

    /** Ставит блок (перезаписывает). */
    public void set(int x, int y, int z, String block) {
        blocks.put(key(x, y, z), block);
    }

    /** Ставит блок, только если место свободно (декор не портит маршрут). */
    public void setIfEmpty(int x, int y, int z, String block) {
        blocks.putIfAbsent(key(x, y, z), block);
    }

    public String get(int x, int y, int z) {
        return blocks.get(key(x, y, z));
    }

    public boolean has(int x, int y, int z) {
        return blocks.containsKey(key(x, y, z));
    }

    public void remove(int x, int y, int z) {
        blocks.remove(key(x, y, z));
    }

    public Map<Long, String> blocks() {
        return blocks;
    }

    public int size() {
        return blocks.size();
    }
}

package dev.dirronlive.parkour.map;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;

/**
 * Детерминированный генератор комнат «Dirron Parkour: 100 комнат».
 *
 * <p>Маршрут идёт вдоль +X. Ограничения прыжков (проверяются тестами):
 * воздух между краями ≤ 3 блока на той же высоте или вниз, ≤ 2 — на +1 вверх;
 * подъём больше чем на 1 блок — только через батут из слизи.
 */
public final class RoomGenerator {
    private RoomGenerator() {}

    /** Плоскость крупного номера комнаты (смещение по X от начала комнаты). */
    static final int NUMBER_X = 20;

    public static RoomPlan generate(int number, int ox, int oy, int oz) {
        if (number < 1 || number > ParkourLayout.ROOMS) {
            throw new IllegalArgumentException("Комната " + number);
        }
        Gen g = new Gen(number, ox, oy, oz);
        if (number == ParkourLayout.ROOMS) {
            g.finalRoom();
        } else {
            g.regularRoom();
        }
        return g.finishPlan();
    }

    /** Механики отрезков маршрута. */
    enum Move { JUMP, RING, DESCENT, RUNWAY, BOUNCE, FORK, BEAM, WALKWAY, CLIMB,
        /** Прыжок за угол: прямо — стена, цель по диагонали. */
        CORNER,
        /** Цепочка точных прыжков на блок 1×1: вверх, ровно, вниз. */
        CHAIN,
        /** Вертикальный подъём зигзагом по 1×1. */
        TOWER,
        /** Разгон по льду и длинный прыжок через 4 блока. */
        SPRINT,
        /** Развилка: безопасный обход или рискованная срезка по столбикам. */
        RISKY }

    private static final class Gen {
        final int number;
        final int ox, oy, oz;
        final Theme theme;
        final Random rnd;
        final double difficulty;
        final double local;
        /** 0 — знакомство с механиками, 1 — точность и цепочки, 2 — подъёмы, разгон, срезки. */
        final int tier;
        final boolean finale;
        final Blueprint bp = new Blueprint();
        final List<Platform> platforms = new ArrayList<>();
        final List<Theme> platformThemes = new ArrayList<>();
        final List<int[]> bridge = new ArrayList<>();
        final List<int[]> shortcut = new ArrayList<>();
        final List<int[]> eyes = new ArrayList<>();
        int bridgeFrom = -1;
        /** Воздух над платформами: сюда декор не ставится. */
        final java.util.Set<Long> reserved = new java.util.HashSet<>();

        Gen(int number, int ox, int oy, int oz) {
            this.number = number;
            this.ox = ox;
            this.oy = oy;
            this.oz = oz;
            this.theme = Theme.forRoom(number);
            this.rnd = new Random(number * 7919L + 104729L);
            // Сложность растёт и внутри десятки, и по всей карте.
            this.local = ((number - 1) % 10) / 9.0;
            this.difficulty = 0.6 * ((number - 1) / 99.0) + 0.4 * local;
            this.tier = number <= 15 ? 0 : (number <= 60 ? 1 : 2);
            this.finale = number % 10 == 0;
        }

        Platform last() {
            return platforms.get(platforms.size() - 1);
        }

        // ------------------------------------------------------------ комнаты

        void regularRoom() {
            addPlatform(ox, oz - 2, ox + 4, oz + 2, oy, Platform.Kind.START, theme);
            // Два прямых прыжка в начале каждой комнаты: первая платформа
            // хорошо заметна, а между ними — размеченный разрыв для «Моста».
            jump(theme, 2, 0, 3, Platform.Kind.FIRST);
            jump(theme, 3, 0, sizeFor(), Platform.Kind.NORMAL);
            bridgeFrom = 1;

            if (theme == Theme.AMETHYST && !finale) {
                spiral(theme, 10 + (int) Math.round(difficulty * 6));
            } else {
                int moves = switch (tier) {
                    case 0 -> 5 + (int) Math.round(local);
                    case 1 -> 7 + (int) Math.round(local * 2);
                    default -> 7 + (int) Math.round(local * 2);
                };
                for (int i = 0; i < moves; i++) {
                    Theme segmentTheme = finale ? Theme.values()[i % 9] : theme;
                    move(tierMove(pickMove(segmentTheme, i), i), segmentTheme);
                }
            }
            finish(theme);
            themeDecor();
            number(theme);
        }

        Move pickMove(Theme t, int i) {
            boolean even = i % 2 == 0;
            return switch (t) {
                case NEON -> even ? Move.JUMP : Move.RING;
                case CORAL -> even ? Move.RING : Move.JUMP;
                case HONEY -> i % 3 == 1 ? Move.DESCENT : (i % 3 == 2 ? Move.CLIMB : Move.JUMP);
                case ICE -> even ? Move.RUNWAY : Move.JUMP;
                case SLIME -> even ? Move.BOUNCE : Move.CLIMB;
                case RASPBERRY -> i % 4 == 1 ? Move.FORK : Move.JUMP;
                case FORGE -> even ? Move.BEAM : Move.JUMP;
                case AMETHYST -> Move.CLIMB;
                case CARNIVAL -> i % 3 == 0 ? Move.WALKWAY : (i % 3 == 1 ? Move.RING : Move.JUMP);
                case ARENA -> Move.values()[(i * 5 + number) % Move.values().length];
            };
        }

        /** Средние и последние комнаты получают новые приёмы поверх темы. */
        Move tierMove(Move base, int i) {
            if (tier == 1 && i % 3 == 2) return (i / 3 + number) % 2 == 0 ? Move.CORNER : Move.CHAIN;
            if (tier == 2 && i % 3 == 1) {
                return switch ((i / 3 + number) % 4) {
                    case 0 -> Move.TOWER;
                    case 1 -> Move.SPRINT;
                    case 2 -> Move.RISKY;
                    default -> Move.CHAIN;
                };
            }
            if (tier == 2 && i % 3 == 2 && base == Move.JUMP) return Move.CORNER;
            if (tier == 0 && (base == Move.BEAM || base == Move.FORK)) return Move.JUMP; // без сложного в начале
            return base;
        }

        void move(Move move, Theme t) {
            switch (move) {
                case JUMP -> jump(t, gapFor(), dyFor(), sizeFor(), Platform.Kind.NORMAL);
                case CLIMB -> jump(t, Math.min(2, gapFor()), 1, sizeFor(), Platform.Kind.NORMAL);
                case RING -> {
                    Platform from = last();
                    Platform to = jump(t, Math.max(2, gapFor()), 0, sizeFor(), Platform.Kind.NORMAL);
                    ring(from, to, t);
                }
                case DESCENT -> {
                    Platform to = jump(t, Math.min(2, gapFor()), -2, Math.max(2, sizeFor()), Platform.Kind.NORMAL);
                    honeySlide(to);
                }
                case RUNWAY -> runway(t);
                case BOUNCE -> bounce(t);
                case FORK -> fork(t);
                case BEAM -> beam(t, false);
                case WALKWAY -> beam(t, true);
                case CORNER -> corner(t);
                case CHAIN -> chain(t);
                case TOWER -> tower(t);
                case SPRINT -> sprint(t);
                case RISKY -> risky(t);
            }
        }

        /** Прыжок за угол: прямо по ходу стоит стена, следующая платформа — по диагонали. */
        void corner(Theme t) {
            Platform from = last();
            int cz = (int) Math.floor(from.centerZ());
            int side = cz <= oz ? 1 : -1;
            int size = tier == 2 ? 1 : 2;
            int x0 = from.x1() + 3;
            int z0 = side > 0 ? from.z1() + (tier == 2 ? 3 : 2) : from.z0() - (tier == 2 ? 3 : 2) - (size - 1);
            z0 = Math.max(oz - 8, Math.min(oz + 8 - (size - 1), z0));
            Platform target = addPlatform(x0, z0, x0 + size - 1, z0 + size - 1, from.y(), Platform.Kind.NORMAL, t);
            // Стена там, куда прыгнул бы игрок напрямую: от края платформы и дальше.
            int wz0 = side > 0 ? from.z0() - 1 : from.z1() + 1;
            int wz1 = side > 0 ? from.z1() : from.z0();
            for (int x = from.x1() + 3; x <= target.x1(); x++) {
                for (int z = Math.min(wz0, wz1); z <= Math.max(wz0, wz1); z++) {
                    for (int y = from.y(); y <= from.y() + 3; y++) decor(x, y, z, t.edge);
                }
            }
            // Выход из угла дальше по ходу.
            jump(t, gapFor() - 1 < 1 ? 1 : gapFor() - 1, 0, sizeFor() + 1, Platform.Kind.NORMAL);
        }

        /** Цепочка из трёх точных прыжков на 1×1: вверх, ровно, вниз. */
        void chain(Theme t) {
            jump(t, 2, 1, 1, Platform.Kind.NORMAL);
            jump(t, tier == 2 ? 3 : 2, 0, 1, Platform.Kind.NORMAL);
            jump(t, 2, -1, tier == 2 ? 1 : 2, Platform.Kind.NORMAL);
        }

        /** Вертикальный подъём зигзагом: 4–6 ступеней +1 на блоках 1×1. */
        void tower(Theme t) {
            int steps = 4 + (int) Math.round(local * 2);
            Platform from = last();
            int y = from.y();
            int x = from.x1() + 2;
            int z = (int) Math.floor(from.centerZ());
            for (int i = 0; i < steps; i++) {
                int dz = (i % 2 == 0) ? 2 : -2;
                int nz = Math.max(oz - 8, Math.min(oz + 8, z + dz));
                y += 1;
                Platform step = addPlatform(x, nz, x, nz, y, Platform.Kind.NORMAL, t);
                // Колонна под ступенью — видно, что это башня.
                for (int yy = y - 1; yy >= y - 3; yy--) decor(step.x0(), yy - 1, step.z0(), t.edge);
                x += 2;
                z = nz;
            }
            jump(t, 2, 0, 2, Platform.Kind.NORMAL);
        }

        /** Разгон по синему льду и прыжок через 4 блока воздуха. */
        void sprint(Theme t) {
            Platform from = last();
            int length = 6 + rnd.nextInt(2);
            int x0 = from.x1() + 2;
            int cz = (int) Math.floor(from.centerZ());
            Platform runway = addPlatform(x0, cz - 1, x0 + length - 1, cz, from.y(), Platform.Kind.RUNWAY, t);
            for (int x = runway.x0(); x <= runway.x1(); x += 2) {
                decor(x, runway.y() + 4, runway.z0() - 1, "minecraft:sea_lantern");
                decor(x, runway.y() + 4, runway.z1() + 1, "minecraft:sea_lantern");
            }
            jump(t, 4, 0, 2, Platform.Kind.NORMAL);
        }

        /**
         * Развилка: безопасный обход из трёх платформ дугой или рискованная
         * срезка напрямую по двум столбикам 1×1 с прыжками на 3 блока.
         */
        void risky(Theme t) {
            Platform from = last();
            int cz = (int) Math.floor(from.centerZ());
            int side = cz <= oz ? 1 : -1;
            int y = from.y();
            // Обход (основной маршрут): две платформы 2×2 дугой в сторону.
            int az0 = side > 0 ? from.z1() + 3 : from.z0() - 4;
            Platform a = addPlatform(from.x1() + 3, az0, from.x1() + 4, az0 + 1, y, Platform.Kind.NORMAL, t);
            Platform b = addPlatform(a.x1() + 3, a.z0() + side * 2, a.x1() + 4, a.z1() + side * 2,
                    y, Platform.Kind.NORMAL, t);
            // Срезка: два столбика 1×1 по прямой, прыжки по 3 блока.
            Platform s1 = addPlatform(from.x1() + 4, cz, from.x1() + 4, cz, y, Platform.Kind.NORMAL, t);
            Platform s2 = addPlatform(s1.x1() + 4, cz, s1.x1() + 4, cz, y, Platform.Kind.NORMAL, t);
            for (Platform pillar : List.of(s1, s2)) {
                for (int yy = y - 2; yy >= y - 5; yy--) decor(pillar.x0(), yy, pillar.z0(), "minecraft:red_concrete");
            }
            // Слияние: площадка, на которую ведут и обход, и срезка.
            int mergeX = b.x1() + 4;
            int z0 = Math.min(Math.min(cz, b.z0()), from.z0());
            int z1 = Math.max(Math.max(cz, b.z1()), from.z1());
            addPlatform(mergeX, z0, mergeX + 1, z1, y, Platform.Kind.NORMAL, t);
        }

        int gapFor() {
            return switch (tier) {
                case 0 -> 1 + rnd.nextInt(2);
                case 1 -> 2 + rnd.nextInt(2);
                default -> rnd.nextInt(4) == 0 ? 2 : 3;
            };
        }

        int dyFor() {
            int r = rnd.nextInt(tier == 0 ? 8 : (tier == 1 ? 6 : 5));
            return switch (r) {
                case 0 -> 1;
                case 1 -> tier == 0 ? 0 : -1;
                case 2 -> tier == 2 ? 1 : 0;
                default -> 0;
            };
        }

        int sizeFor() {
            return switch (tier) {
                case 0 -> 3;
                case 1 -> local < 0.4 ? 2 : (rnd.nextBoolean() ? 2 : 1);
                default -> rnd.nextInt(3) == 0 ? 2 : 1;
            };
        }

        /** Следующая платформа на расстоянии {@code gap} блоков воздуха по X. */
        Platform jump(Theme t, int gap, int dy, int size, Platform.Kind kind) {
            Platform from = last();
            if (dy > 0) gap = Math.min(gap, 2);
            int y = from.y() + dy;
            int x0 = from.x1() + 1 + gap;
            int x1 = x0 + size - 1;
            int shift = rnd.nextInt(5) - 2;
            int cz = (int) Math.floor(from.centerZ()) + shift;
            cz = Math.max(oz - 7, Math.min(oz + 7, cz));
            int z0 = cz - (size - 1) / 2;
            int z1 = z0 + size - 1;
            // Боковое смещение не должно удлинять прыжок сверх допустимого.
            Platform candidate = new Platform(platforms.size(), x0, z0, x1, z1, y, kind);
            double limit = dy > 0 ? 2.25 : 3.2;
            while (from.airGapTo(candidate) > limit && z0 != (int) Math.floor(from.centerZ()) - (size - 1) / 2) {
                int dir = z0 > from.z0() ? -1 : 1;
                z0 += dir;
                z1 += dir;
                candidate = new Platform(platforms.size(), x0, z0, x1, z1, y, kind);
            }
            return addPlatform(x0, z0, x1, z1, y, kind, t);
        }

        /** Ледяная аркада: длинная дорожка из синего льда для разгона. */
        void runway(Theme t) {
            Platform from = last();
            int length = 5 + rnd.nextInt(3);
            int x0 = from.x1() + 1 + Math.min(2, gapFor());
            int cz = (int) Math.floor(from.centerZ());
            Platform runway = addPlatform(x0, cz - 1, x0 + length - 1, cz, from.y(), Platform.Kind.RUNWAY, t);
            // Арки аркады над дорожкой.
            for (int x = runway.x0(); x <= runway.x1(); x += 3) {
                for (int z = runway.z0() - 1; z <= runway.z1() + 1; z++) {
                    decor(x, runway.y() + 4, z, "minecraft:magenta_stained_glass");
                }
                decor(x, runway.y() + 1, runway.z0() - 2, "minecraft:magenta_stained_glass");
                decor(x, runway.y() + 2, runway.z0() - 2, "minecraft:magenta_stained_glass");
                decor(x, runway.y() + 3, runway.z0() - 2, "minecraft:sea_lantern");
                decor(x, runway.y() + 1, runway.z1() + 2, "minecraft:magenta_stained_glass");
                decor(x, runway.y() + 2, runway.z1() + 2, "minecraft:magenta_stained_glass");
                decor(x, runway.y() + 3, runway.z1() + 2, "minecraft:sea_lantern");
            }
            // Точное торможение: широкая площадка после прыжка с разгона.
            jump(t, 3, 0, 3, Platform.Kind.NORMAL);
        }

        /** Слайм-батут: спрыгнуть на слизь на 3 ниже и отскочить на площадку. */
        void bounce(Theme t) {
            Platform from = last();
            int x0 = from.x1() + 2;
            int cz = (int) Math.floor(from.centerZ());
            addPlatform(x0, cz - 1, x0 + 2, cz + 1, from.y() - 3, Platform.Kind.BOUNCE, t);
            Platform pad = last();
            int lx0 = pad.x1() + 3;
            addPlatform(lx0, cz - 1, lx0 + 1, cz, from.y() - 1, Platform.Kind.NORMAL, t);
            // Стеклянная стенка лаборатории за батутом.
            for (int y = pad.y() - 1; y <= pad.y() + 1; y++) {
                for (int z = pad.z0() - 1; z <= pad.z1() + 1; z++) {
                    decor(pad.x0() - 1, y - 1, z, "minecraft:lime_stained_glass");
                }
            }
        }

        /** Малиновые сады: развилка на два пути, которые сходятся. */
        void fork(Theme t) {
            Platform from = last();
            int cz = (int) Math.floor(from.centerZ());
            int y = from.y();
            int baseX = from.x1() + 3;
            // Левая ветка (в сторону -Z) и правая (+Z): по две платформы.
            Platform l1 = addPlatform(baseX, cz - 4, baseX + 1, cz - 3, y, Platform.Kind.NORMAL, t);
            Platform r1 = addPlatform(baseX, cz + 3, baseX + 1, cz + 4, y + 1, Platform.Kind.NORMAL, t);
            Platform l2 = addPlatform(l1.x1() + 3, cz - 4, l1.x1() + 4, cz - 3, y, Platform.Kind.NORMAL, t);
            Platform r2 = addPlatform(r1.x1() + 3, cz + 3, r1.x1() + 4, cz + 4, y + 1, Platform.Kind.NORMAL, t);
            // Слияние.
            int mx0 = Math.max(l2.x1(), r2.x1()) + 3;
            addPlatform(mx0, cz - 1, mx0 + 2, cz + 1, y, Platform.Kind.NORMAL, t);
            // Цветущие арки над ветками.
            arch(l1, "minecraft:flowering_azalea_leaves[persistent=true]");
            arch(r2, "minecraft:cherry_leaves[persistent=true]");
        }

        void arch(Platform p, String leaves) {
            int top = p.y() + 5;
            for (int z = p.z0() - 1; z <= p.z1() + 1; z++) {
                decor((int) Math.floor(p.centerX()), top, z, leaves);
            }
            for (int y = p.y() + 1; y < top; y++) {
                decor((int) Math.floor(p.centerX()), y, p.z0() - 1, "minecraft:cherry_log");
                decor((int) Math.floor(p.centerX()), y, p.z1() + 1, "minecraft:cherry_log");
            }
        }

        /** Огненная кузница: узкая медная балка (или подвесная дорожка карнавала). */
        void beam(Theme t, boolean suspended) {
            Platform from = last();
            int length = 4 + rnd.nextInt(3);
            int x0 = from.x1() + 1 + Math.min(2, gapFor());
            int z = (int) Math.floor(from.centerZ());
            Platform beam = addPlatform(x0, z, x0 + length - 1, z, from.y(), Platform.Kind.BEAM, t);
            if (suspended) {
                for (int x : new int[] {beam.x0(), beam.x1()}) {
                    for (int y = beam.y() + 3; y <= beam.y() + 6; y++) {
                        decor(x, y, z - 1, "minecraft:chain[axis=y]");
                        decor(x, y, z + 1, "minecraft:chain[axis=y]");
                    }
                    for (int dz = -1; dz <= 1; dz++) {
                        decor(x, beam.y() + 7, z + dz, "minecraft:red_concrete");
                    }
                }
            } else {
                for (int x = beam.x0(); x <= beam.x1(); x += 2) {
                    decor(x, beam.y() - 3, z, "minecraft:furnace[lit=true,facing=north]");
                    decor(x, beam.y() - 4, z, "minecraft:magma_block");
                }
            }
            jump(t, 2, 0, Math.max(2, sizeFor()), Platform.Kind.NORMAL);
        }

        /** Аметистовые пещеры: подъём по спирали вокруг центральной шахты. */
        void spiral(Theme t, int steps) {
            Platform from = last();
            double cx = Math.max(from.x1() + 8, ox + 30);
            double cz = oz;
            double radius = 5.0;
            double angle = Math.PI; // начинаем с ближней к старту стороны
            // Подход к шахте: ступени, пока до первой точки спирали не останется прыжок.
            approach((int) Math.round(cx + Math.cos(angle) * radius) - 1,
                    (int) Math.round(cz + Math.sin(angle) * radius) - 1, t);
            int y = last().y();
            for (int i = 0; i < steps; i++) {
                int px = (int) Math.round(cx + Math.cos(angle) * radius) - 1;
                int pz = (int) Math.round(cz + Math.sin(angle) * radius) - 1;
                Platform previous = last();
                Platform next = new Platform(platforms.size(), px, pz, px + 1, pz + 1, y + 1, Platform.Kind.NORMAL);
                if (previous.airGapTo(next) > 2.25 || i == 0) {
                    // Первая ступень — с подходом: на той же высоте, если далеко.
                    next = new Platform(platforms.size(), px, pz, px + 1, pz + 1,
                            previous.airGapTo(next) > 2.25 ? y : y + 1, Platform.Kind.NORMAL);
                }
                addPlatform(next.x0(), next.z0(), next.x1(), next.z1(), next.y(), Platform.Kind.NORMAL, t);
                y = next.y();
                angle += Math.toRadians(52);
            }
            // Центральная шахта из кристаллов.
            int top = y + 6;
            for (int yy = from.y() - 6; yy <= top; yy++) {
                for (int dx = -1; dx <= 1; dx++) {
                    for (int dz = -1; dz <= 1; dz++) {
                        boolean core = dx == 0 && dz == 0;
                        decor((int) cx + dx, yy, (int) cz + dz,
                                core ? "minecraft:pearlescent_froglight"
                                        : (yy % 3 == 0 ? "minecraft:tinted_glass" : "minecraft:amethyst_block"));
                    }
                }
            }
        }

        /** Ступени 2×2 по прямой к точке (tx, tz) на той же высоте (воздух ≤ 2). */
        void approach(int tx, int tz, Theme t) {
            for (int guard = 0; guard < 20; guard++) {
                Platform from = last();
                Platform target = new Platform(-1, tx, tz, tx + 1, tz + 1, from.y(), Platform.Kind.NORMAL);
                if (from.airGapTo(target) <= 2.5) return;
                double dx = target.centerX() - from.centerX();
                double dz = target.centerZ() - from.centerZ();
                double len = Math.hypot(dx, dz);
                double reach = Math.min(len, 4.0);
                int nx = (int) Math.round(from.centerX() + dx / len * reach) - 1;
                int nz = (int) Math.round(from.centerZ() + dz / len * reach) - 1;
                Platform next = new Platform(-1, nx, nz, nx + 1, nz + 1, from.y(), Platform.Kind.NORMAL);
                while (from.airGapTo(next) > 2.2 && reach > 2.5) {
                    reach -= 0.5;
                    nx = (int) Math.round(from.centerX() + dx / len * reach) - 1;
                    nz = (int) Math.round(from.centerZ() + dz / len * reach) - 1;
                    next = new Platform(-1, nx, nz, nx + 1, nz + 1, from.y(), Platform.Kind.NORMAL);
                }
                addPlatform(nx, nz, nx + 1, nz + 1, from.y(), Platform.Kind.NORMAL, t);
            }
        }

        void ring(Platform from, Platform to, Theme t) {
            double midX = (from.x1() + 1 + to.x0()) / 2.0;
            int x = (int) Math.floor(midX);
            double cy = from.y() + 2.5;
            double cz = (from.centerZ() + to.centerZ()) / 2.0;
            String a = t == Theme.CARNIVAL ? "minecraft:red_concrete" : t.accent;
            String b = t == Theme.CARNIVAL ? "minecraft:yellow_concrete" : t.main;
            for (int y = (int) cy - 4; y <= (int) cy + 4; y++) {
                for (int z = (int) cz - 4; z <= (int) cz + 4; z++) {
                    double d = Math.hypot(y + 0.5 - cy, z + 0.5 - cz);
                    if (d >= 2.9 && d <= 3.8) {
                        decor(x, y, z, ((y + z) & 1) == 0 ? a : b);
                    }
                }
            }
        }

        void honeySlide(Platform p) {
            int x = p.x0() - 1;
            for (int y = p.y() + 1; y <= p.y() + 3; y++) {
                decor(x, y, p.z0() - 1, "minecraft:honey_block");
            }
        }

        void finish(Theme t) {
            Platform from = last();
            int x0 = from.x1() + 3;
            int cz = (int) Math.floor(from.centerZ());
            Platform f = addPlatform(x0, cz - 1, x0 + 2, cz + 1, from.y(), Platform.Kind.FINISH, t);
            finishGate(f);
        }

        /** Единое оформление выхода: чёрные колонны, лаймовая перекладина, свет. */
        void finishGate(Platform f) {
            int x = (int) Math.floor(f.centerX());
            java.util.function.BiConsumer<int[], String> gate = (pos, block) -> {
                if (!reserved.contains(Blueprint.key(pos[0], pos[1], pos[2]))) bp.set(pos[0], pos[1], pos[2], block);
            };
            for (int y = f.y() + 1; y <= f.y() + 4; y++) {
                gate.accept(new int[] {x, y, f.z0() - 1}, "minecraft:black_concrete");
                gate.accept(new int[] {x, y, f.z1() + 1}, "minecraft:black_concrete");
            }
            for (int z = f.z0() - 1; z <= f.z1() + 1; z++) {
                gate.accept(new int[] {x, f.y() + 5, z}, "minecraft:lime_concrete");
            }
            gate.accept(new int[] {x, f.y() + 5, (int) Math.floor(f.centerZ())}, "minecraft:verdant_froglight");
            gate.accept(new int[] {x, f.y() + 4, f.z0() - 1}, "minecraft:verdant_froglight");
            gate.accept(new int[] {x, f.y() + 4, f.z1() + 1}, "minecraft:verdant_froglight");
        }

        // ------------------------------------------------------- комната 100

        /** Подъём вокруг огромной буквы D; финиш на её вершине виден снизу. */
        void finalRoom() {
            addPlatform(ox, oz - 2, ox + 4, oz + 2, oy, Platform.Kind.START, Theme.ARENA);
            jump(Theme.ARENA, 2, 0, 3, Platform.Kind.FIRST);
            jump(Theme.ARENA, 3, 0, 3, Platform.Kind.NORMAL);
            bridgeFrom = 1;

            // Буква D в плоскости YZ (лицом к старту), толщина по X.
            int dx0 = ox + 30, dx1 = ox + 34;
            int dz0 = oz - 10, dz1 = oz + 10;
            int dy0 = oy - 2, dy1 = oy + 30;
            int width = dz1 - dz0 + 1, height = dy1 - dy0 + 1;
            for (int y = dy0; y <= dy1; y++) {
                for (int z = dz0; z <= dz1; z++) {
                    int u = z - dz0, v = y - dy0;
                    if (letterD(u, v, width, height)) {
                        for (int x = dx0; x <= dx1; x++) {
                            bp.set(x, y, z, x == dx0 ? "minecraft:purple_concrete" : "minecraft:magenta_concrete");
                        }
                    } else if (insideCounter(u, v, width, height)) {
                        bp.set(dx1, y, z, "minecraft:black_concrete"); // тёмная глубина буквы
                    }
                }
            }
            // Глаза логотипа на тёмном фоне внутри D (загораются после финиша).
            int eyeY = oy + 13;
            for (int ez : new int[] {oz - 3, oz + 2}) {
                for (int y = eyeY; y < eyeY + 3; y++) {
                    for (int z = ez - 1; z <= ez + 1; z++) {
                        bp.set(dx1 - 1, y, z, "minecraft:gray_concrete");
                        eyes.add(new int[] {dx1 - 1, y, z});
                    }
                }
            }

            // Подход к букве.
            int rx0 = dx0 - 4, rx1 = dx1 + 3, rz0 = dz0 - 4, rz1 = dz1 + 3;
            while (last().x1() < rx0 - 3) {
                jump(Theme.ARENA, 2, 0, 2, Platform.Kind.NORMAL);
            }
            // Спираль по прямоугольнику вокруг буквы: каждая ступень на 1 выше.
            double perimeter = 2.0 * ((rx1 - rx0) + (rz1 - rz0));
            double t = Math.max(0, rz1 - Math.floor(last().centerZ()));
            boolean rising = true;
            int y = last().y();
            for (int guard = 0; guard < 2000; guard++) {
                double[] p = rectPoint(rx0, rz0, rx1, rz1, t % perimeter);
                t += 1.0;
                int px = (int) Math.floor(p[0]);
                int pz = (int) Math.floor(p[1]);
                Platform previous = last();
                double manhattan = Math.abs(px + 1 - previous.centerX()) + Math.abs(pz + 1 - previous.centerZ());
                if (manhattan < 4.0) continue;
                int ny = rising ? y + 1 : y;
                Platform next = new Platform(platforms.size(), px, pz, px + 1, pz + 1, ny, Platform.Kind.NORMAL);
                if (previous.airGapTo(next) > (ny > previous.y() ? 2.25 : 3.2)) continue;
                Theme style = Theme.values()[platforms.size() % 10];
                addPlatform(px, pz, px + 1, pz + 1, ny, Platform.Kind.NORMAL, style);
                y = ny;
                if (y >= dy1) rising = false;
                // На высоте вершины идём до ближней стороны у «ножки» буквы.
                if (!rising && px <= rx0 && pz <= dz0 + 3) break;
            }
            // Ступень у вершины и финиш на верхней перекладине буквы.
            Platform top = last();
            Platform step = addPlatform(dx0 - 2, top.z0(), dx0 - 1, top.z1(), dy1, Platform.Kind.NORMAL, Theme.ARENA);
            Platform f = addPlatform(dx0 + 1, Math.max(dz0, step.z0() - 1), dx0 + 3,
                    Math.max(dz0, step.z0() - 1) + 2, dy1 + 1, Platform.Kind.FINISH, Theme.ARENA);
            finishGate(f);
            number(Theme.ARENA);
            // Фиолетово-лаймовая арена вокруг основания.
            for (int x = ox - 2; x <= dx1 + 8; x += 2) {
                decor(x, oy - 8, oz - 16, "minecraft:lime_concrete");
                decor(x, oy - 8, oz + 16, "minecraft:purple_concrete");
            }
        }

        static double[] rectPoint(int x0, int z0, int x1, int z1, double t) {
            double w = x1 - x0, h = z1 - z0;
            // Обход: ближняя к старту сторона (x0) от z1 к z0, дальше по кругу.
            if (t < h) return new double[] {x0, z1 - t};
            t -= h;
            if (t < w) return new double[] {x0 + t, z0};
            t -= w;
            if (t < h) return new double[] {x1, z0 + t};
            t -= h;
            return new double[] {x1 - t, z1};
        }

        static final int STEM = 5;

        /** Правая граница буквы в строке v (u — по ширине, v — снизу). */
        static double outerEdge(int v, int width, int height) {
            double cy = (height - 1) / 2.0, ry = height / 2.0;
            double ny = (v - cy) / ry;
            if (Math.abs(ny) > 1) return STEM;
            return STEM + (width - STEM) * Math.sqrt(Math.max(0, 1 - ny * ny));
        }

        /** Левая граница внутреннего «окна» буквы в строке v. */
        static double innerEdge(int v, int width, int height) {
            double cy = (height - 1) / 2.0, ry = height / 2.0 - 5;
            double ny = (v - cy) / ry;
            if (Math.abs(ny) >= 1) return -1;
            return STEM + (width - STEM - 5) * Math.sqrt(1 - ny * ny);
        }

        /** Пиксель буквы D. */
        static boolean letterD(int u, int v, int width, int height) {
            if (u < STEM) return true;
            double outer = outerEdge(v, width, height);
            if (u >= Math.max(outer, v < 5 || v >= height - 5 ? STEM + (width - STEM) * 0.55 : outer)) return false;
            if (v < 5 || v >= height - 5) return true;
            double inner = innerEdge(v, width, height);
            return inner < 0 || u >= inner;
        }

        /** Внутреннее «окно» буквы (тёмный фон для глаз). */
        static boolean insideCounter(int u, int v, int width, int height) {
            return u >= STEM && v >= 5 && v < height - 5 && !letterD(u, v, width, height)
                    && u < outerEdge(v, width, height);
        }

        // ------------------------------------------------------------- общее

        /** Декор: только в пустоту и не над платформами. */
        void decor(int x, int y, int z, String block) {
            long key = Blueprint.key(x, y, z);
            if (!reserved.contains(key)) bp.setIfEmpty(x, y, z, block);
        }

        Platform addPlatform(int x0, int z0, int x1, int z1, int y, Platform.Kind kind, Theme t) {
            Platform p = new Platform(platforms.size(), x0, z0, x1, z1, y, kind);
            platforms.add(p);
            platformThemes.add(t);
            // Над платформой всегда 3 блока воздуха: убираем декор, если он там был.
            for (int x = x0; x <= x1; x++) {
                for (int z = z0; z <= z1; z++) {
                    for (int dy = 1; dy <= 3; dy++) {
                        bp.remove(x, y + dy, z);
                        reserved.add(Blueprint.key(x, y + dy, z));
                    }
                }
            }
            int w = x1 - x0 + 1, d = z1 - z0 + 1;
            boolean bigEnough = w >= 3 && d >= 3;
            for (int x = x0; x <= x1; x++) {
                for (int z = z0; z <= z1; z++) {
                    boolean border = x == x0 || x == x1 || z == z0 || z == z1;
                    String top = switch (kind) {
                        case START -> (x == (x0 + x1) / 2 && z == (z0 + z1) / 2) ? "minecraft:lodestone"
                                : (border ? t.edge : t.main);
                        case FIRST -> border && bigEnough ? "minecraft:white_concrete" : "minecraft:lime_concrete";
                        case RUNWAY -> "minecraft:blue_ice";
                        case BOUNCE -> "minecraft:slime_block";
                        case BEAM -> t == Theme.CARNIVAL ? "minecraft:white_concrete" : "minecraft:waxed_cut_copper";
                        case FINISH -> "minecraft:gold_block";
                        default -> bigEnough && border ? t.edge : t.main;
                    };
                    bp.set(x, y, z, top);
                    String under = bigEnough ? t.main : t.edge;
                    if (kind == Platform.Kind.FINISH || kind == Platform.Kind.FIRST) under = "minecraft:verdant_froglight";
                    bp.set(x, y - 1, z, under);
                }
            }
            // Подсветка снизу — видна издалека и с обычной графикой.
            int cx = (int) Math.floor(p.centerX());
            int cz = (int) Math.floor(p.centerZ());
            if (kind != Platform.Kind.BOUNCE) {
                bp.set(cx, y - 1, cz, t == Theme.FORGE ? "minecraft:furnace[lit=true,facing=north]" : t.light);
            }
            return p;
        }

        /** Крупный номер комнаты над маршрутом, лицом к старту. */
        void number(Theme t) {
            String text = Integer.toString(number);
            int scale = 2;
            int digitWidth = 3 * scale;
            int spacing = 2;
            int total = text.length() * digitWidth + (text.length() - 1) * spacing;
            int zStart = oz - total / 2;
            int yTop = oy + 7 + 5 * scale - 1;
            int x = ox + NUMBER_X;
            for (int i = 0; i < text.length(); i++) {
                int digit = text.charAt(i) - '0';
                int z0 = zStart + i * (digitWidth + spacing);
                for (int col = 0; col < 3; col++) {
                    for (int row = 0; row < 5; row++) {
                        if (!DigitFont.pixel(digit, col, row)) continue;
                        for (int sz = 0; sz < scale; sz++) {
                            for (int sy = 0; sy < scale; sy++) {
                                decor(x, yTop - row * scale - sy, z0 + col * scale + sz, t.light);
                            }
                        }
                    }
                }
            }
        }

        void themeDecor() {
            int minX = Integer.MAX_VALUE, maxX = Integer.MIN_VALUE, minY = Integer.MAX_VALUE;
            for (Platform p : platforms) {
                minX = Math.min(minX, p.x0());
                maxX = Math.max(maxX, p.x1());
                minY = Math.min(minY, p.y());
            }
            switch (theme) {
                case NEON -> {
                    // Улица далеко внизу и вывески по сторонам.
                    for (int x = minX - 2; x <= maxX + 2; x++) {
                        for (int z = oz - 3; z <= oz + 3; z++) {
                            decor(x, minY - 14, z, "minecraft:black_concrete");
                        }
                        if (x % 4 < 2) decor(x, minY - 14, oz, "minecraft:yellow_concrete");
                    }
                    for (int x = minX + 6; x <= maxX; x += 14) {
                        billboard(x, oz - 11, minY + 2, "minecraft:cyan_stained_glass", "minecraft:sea_lantern");
                        billboard(x + 7, oz + 11, minY + 2, "minecraft:magenta_stained_glass", "minecraft:sea_lantern");
                    }
                }
                case CORAL -> pool(minX - 2, maxX + 2, oz - 9, oz + 9, minY - 6);
                case HONEY -> {
                    for (int x = minX; x <= maxX; x++) {
                        for (int y = minY - 4; y <= minY + 6; y++) {
                            decor(x, y, oz - 10, (x + y) % 5 == 0 ? "minecraft:honey_block" : "minecraft:honeycomb_block");
                        }
                    }
                }
                case SLIME -> {
                    for (int x = minX; x <= maxX; x += 5) {
                        for (int y = minY - 2; y <= minY + 5; y++) {
                            decor(x, y, oz - 10, "minecraft:lime_stained_glass");
                            decor(x, y, oz + 10, "minecraft:lime_stained_glass");
                        }
                        decor(x, minY + 6, oz - 10, "minecraft:verdant_froglight");
                        decor(x, minY + 6, oz + 10, "minecraft:verdant_froglight");
                    }
                }
                case FORGE -> {
                    for (int x = minX; x <= maxX; x++) {
                        decor(x, minY - 7, oz, "minecraft:magma_block");
                        if (x % 6 == 0) {
                            for (int y = minY - 6; y <= minY + 6; y++) {
                                decor(x, y, oz - 9, "minecraft:waxed_cut_copper");
                                decor(x, y, oz + 9, "minecraft:waxed_cut_copper");
                            }
                        }
                    }
                }
                case CARNIVAL -> {
                    String[] colors = {"minecraft:red_wool", "minecraft:yellow_wool", "minecraft:light_blue_wool", "minecraft:lime_wool"};
                    int c = 0;
                    for (int x = minX + 4; x <= maxX; x += 9) {
                        balloon(x, minY + 7, oz - 10, colors[c++ % colors.length]);
                        balloon(x + 4, minY + 9, oz + 10, colors[c++ % colors.length]);
                    }
                }
                case ARENA -> {
                    for (int x = minX; x <= maxX; x++) {
                        for (int y = minY - 3; y <= minY + 4; y++) {
                            String block = ((x / 2 + y) & 1) == 0 ? "minecraft:purple_concrete" : "minecraft:lime_concrete";
                            decor(x, y, oz - 11, block);
                            decor(x, y, oz + 11, block);
                        }
                    }
                }
                default -> { }
            }
        }

        void billboard(int x, int z, int y, String glass, String light) {
            for (int dx = 0; dx < 6; dx++) {
                for (int dy = 0; dy < 4; dy++) {
                    boolean border = dx == 0 || dx == 5 || dy == 0 || dy == 3;
                    decor(x + dx, y + dy, z, border ? light : glass);
                }
            }
        }

        void balloon(int x, int y, int z, String wool) {
            for (int dx = -2; dx <= 2; dx++) {
                for (int dy = -2; dy <= 2; dy++) {
                    for (int dz = -2; dz <= 2; dz++) {
                        if (dx * dx + dy * dy + dz * dz <= 5) decor(x + dx, y + dy, z + dz, wool);
                    }
                }
            }
            for (int dy = 3; dy <= 6; dy++) decor(x, y - dy, z, "minecraft:chain[axis=y]");
        }

        /** Закрытый бассейн: вода не растекается за борт. */
        void pool(int x0, int x1, int z0, int z1, int y) {
            for (int x = x0; x <= x1; x++) {
                for (int z = z0; z <= z1; z++) {
                    decor(x, y - 1, z, "minecraft:prismarine_bricks");
                    boolean rim = x == x0 || x == x1 || z == z0 || z == z1;
                    decor(x, y, z, rim ? "minecraft:dark_prismarine" : "minecraft:water");
                    if (!rim && (x * 7 + z * 3) % 23 == 0) bp.set(x, y - 1, z, "minecraft:sea_lantern");
                }
            }
        }

        // ------------------------------------------------- точки для действий

        void prepareActionPoints() {
            // Мост: размеченный разрыв между первой платформой и следующей.
            Platform a = platforms.get(bridgeFrom);
            Platform b = platforms.get(bridgeFrom + 1);
            int y = a.y();
            int zA = (int) Math.floor(a.centerZ());
            int zB = (int) Math.floor(b.centerZ());
            int fromX = a.x1() + 1, toX = b.x0() - 1;
            for (int x = fromX; x <= toX; x++) {
                double t = toX == fromX ? 1 : (x - fromX) / (double) (toX - fromX);
                int z = (int) Math.round(zA + (zB - zA) * t);
                for (int dz = 0; dz <= 1; dz++) {
                    if (!bp.has(x, y, z + dz)) bridge.add(new int[] {x, y, z + dz});
                }
            }
            // Метки разрыва: лаймовая полоса под краями обеих платформ.
            for (int z = a.z0(); z <= a.z1(); z++) bp.set(a.x1(), a.y() - 1, z, "minecraft:lime_concrete");
            for (int z = b.z0(); z <= b.z1(); z++) bp.set(b.x0(), b.y() - 1, z, "minecraft:lime_concrete");

            // Срезка: от первой платформы к платформе на 4 позже (не финиш).
            int targetIndex = Math.min(5, platforms.size() - 2);
            Platform from = platforms.get(1);
            Platform to = platforms.get(targetIndex);
            int x0 = (int) Math.floor(from.centerX()), z0 = (int) Math.floor(from.centerZ());
            int x1 = (int) Math.floor(to.centerX()), z1 = (int) Math.floor(to.centerZ());
            int steps = Math.max(Math.abs(x1 - x0), Math.abs(z1 - z0));
            int lastY = from.y();
            int sinceClimb = 0;
            int side = z1 >= z0 ? -3 : 3; // боковая дорожка в стороне от основного маршрута
            for (int i = 1; i < steps; i++) {
                double t = i / (double) steps;
                int x = (int) Math.round(x0 + (x1 - x0) * t);
                double bend = Math.sin(Math.PI * t) * side;
                int z = (int) Math.round(z0 + (z1 - z0) * t + bend);
                int targetY = (int) Math.round(from.y() + (to.y() - from.y()) * t);
                int py = lastY;
                if (targetY > lastY && sinceClimb >= 1) {
                    py = lastY + 1;
                    sinceClimb = 0;
                } else if (targetY < lastY) {
                    py = lastY - 1;
                    sinceClimb = 0;
                } else {
                    sinceClimb++;
                }
                lastY = py;
                if (!bp.has(x, py, z)) shortcut.add(new int[] {x, py, z});
            }
        }

        RoomPlan finishPlan() {
            prepareActionPoints();
            int minX = Integer.MAX_VALUE, minY = Integer.MAX_VALUE, minZ = Integer.MAX_VALUE;
            int maxX = Integer.MIN_VALUE, maxY = Integer.MIN_VALUE, maxZ = Integer.MIN_VALUE;
            for (long key : bp.blocks().keySet()) {
                int x = Blueprint.keyX(key), y = Blueprint.keyY(key), z = Blueprint.keyZ(key);
                minX = Math.min(minX, x);
                minY = Math.min(minY, y);
                minZ = Math.min(minZ, z);
                maxX = Math.max(maxX, x);
                maxY = Math.max(maxY, y);
                maxZ = Math.max(maxZ, z);
            }
            int lowest = Integer.MAX_VALUE;
            for (Platform p : platforms) lowest = Math.min(lowest, p.y());
            List<Integer> vanish = new ArrayList<>();
            for (Platform p : platforms) {
                if (p.kind() != Platform.Kind.START && p.kind() != Platform.Kind.FINISH) vanish.add(p.index());
            }
            Platform start = platforms.get(0);
            Platform first = platforms.get(1);
            double sx = start.centerX();
            double sz = start.centerZ();
            float yaw = (float) Math.toDegrees(Math.atan2(-(first.centerX() - sx), first.centerZ() - sz));
            return new RoomPlan(number, theme, platforms, sx, start.y() + 1, sz, yaw, lowest - 5,
                    new int[] {minX, minY, minZ, maxX, maxY, maxZ}, bridge, shortcut, vanish, eyes, bp);
        }
    }
}

package dev.dirronlive.bridge;

import dev.dirronlive.parkour.world.ParkourActions;
import dev.dirronlive.parkour.world.ParkourWorld;
import java.util.UUID;
import java.util.function.Consumer;
import net.minecraft.client.MinecraftClient;
import net.minecraft.server.integrated.IntegratedServer;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.sound.SoundEvents;
import net.minecraft.text.MutableText;
import net.minecraft.text.Text;
import net.minecraft.util.Formatting;

/** Всё, что мод делает внутри Minecraft. */
final class MinecraftGame implements BridgeConnection.Game {
    private volatile boolean worldReady;

    /**
     * Мир готов: запущен одиночный мир (встроенный сервер) и есть локальный
     * игрок. Вызывается каждый тик в игровом потоке.
     */
    boolean updateWorldReady(MinecraftClient client) {
        boolean ready = client.isIntegratedServerRunning()
                && client.getServer() != null
                && client.world != null
                && client.player != null;
        worldReady = ready;
        return ready;
    }

    @Override
    public boolean isWorldReady() {
        return worldReady;
    }

    @Override
    public void runOnGameThread(Runnable task) {
        MinecraftClient.getInstance().execute(task);
    }

    @Override
    public boolean showGift(BridgeProtocol.Gift gift) {
        MinecraftClient client = MinecraftClient.getInstance();
        if (!updateWorldReady(client) || client.inGameHud == null) return false;

        // «Dirronlive • Alex отправил «Роза» ×5» над панелью быстрого доступа.
        // Серия подарков приходит сюда один раз — с итоговым количеством.
        MutableText text = Text.literal("Dirronlive").formatted(Formatting.LIGHT_PURPLE, Formatting.BOLD)
                .append(Text.literal(" • ").formatted(Formatting.GRAY))
                .append(Text.literal(gift.viewerName()).formatted(Formatting.WHITE, Formatting.BOLD))
                .append(Text.literal(" отправил ").formatted(Formatting.GRAY))
                .append(Text.literal(gift.giftText()).formatted(Formatting.GOLD));
        client.inGameHud.setOverlayMessage(text, false);
        if (client.player != null) {
            client.player.playSound(SoundEvents.ENTITY_EXPERIENCE_ORB_PICKUP, 0.6f, 1.4f);
        }
        return true;
    }

    @Override
    public void runAction(BridgeProtocol.Action action, Consumer<BridgeProtocol.ActionResult> done) {
        MinecraftClient client = MinecraftClient.getInstance();
        IntegratedServer server = client.getServer();
        if (!updateWorldReady(client) || server == null || client.player == null) {
            done.accept(new BridgeProtocol.ActionResult(false, "Мир не открыт — действие не выполнено", 0));
            return;
        }
        UUID uuid = client.player.getUuid();
        // Карта живёт на встроенном сервере — выполняем действие в его потоке.
        server.execute(() -> {
            try {
                ServerPlayerEntity player = server.getPlayerManager().getPlayer(uuid);
                if (player == null) {
                    done.accept(new BridgeProtocol.ActionResult(false, "Игрок ещё не вошёл в мир", 0));
                    return;
                }
                ParkourWorld pw = ParkourWorld.get(server);
                if (!pw.state.built) {
                    done.accept(new BridgeProtocol.ActionResult(false, "Это не мир Dirron Parkour", 0));
                    return;
                }
                String label = action.test() ? "Тест" : action.viewerName().isEmpty() ? action.label()
                        : action.viewerName() + (action.label().isEmpty() ? "" : " · " + action.label());
                // Очередь: одна штука = одно срабатывание, повтор total ничего не добавляет.
                pw.actions.submit(player, action.id(), action.action(), action.params(), label, action.total(),
                        p -> done.accept(new BridgeProtocol.ActionResult(p.ok() > 0 || p.done() == 0, p.result(),
                                p.room(), p.accepted(), p.done(), p.queued(), p.finished())));
            } catch (RuntimeException e) {
                done.accept(new BridgeProtocol.ActionResult(false, "Ошибка в моде: " + e.getClass().getSimpleName(), 0));
            }
        });
    }

    @Override
    public BridgeProtocol.ParkourStatus parkourStatus() {
        if (!worldReady) return new BridgeProtocol.ParkourStatus(false, 0, false, 0, 0);
        ParkourWorld.Status s = ParkourWorld.lastStatus;
        return new BridgeProtocol.ParkourStatus(s.available(), s.room(), s.finished(), s.falls(), s.ticks() / 20,
                s.roomFalls(), s.bestRoom(), s.bestTicks() / 20, s.queued());
    }

    @Override
    public void countdown(BridgeProtocol.Countdown countdown) {
        IntegratedServer server = MinecraftClient.getInstance().getServer();
        if (server == null) return;
        server.execute(() -> ParkourWorld.get(server).countdown(countdown.id(), countdown.title(), countdown.seconds()));
    }
}

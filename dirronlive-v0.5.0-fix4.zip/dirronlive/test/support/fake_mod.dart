import 'dart:convert';
import 'dart:io';

import 'package:flutter_test/flutter_test.dart';

/// «Поддельный мод»: подключается к Dirronlive по WebSocket и говорит тем же
/// протоколом, что и Dirronlive Bridge в Minecraft.
class FakeMod {
  FakeMod._(this.socket) {
    socket.listen(
      (data) {
        final message = (jsonDecode(data as String) as Map).cast<String, Object?>();
        messages.add(message);
        if (message['type'] == 'action' && respondToActions) _respond(message);
      },
      onDone: () => closed = true,
    );
  }

  /// Отвечать на действия паркура, как мод 2.0 на карте.
  bool respondToActions = false;

  /// Комната игрока на «карте».
  int room = 12;

  List<Map<String, Object?>> get actions =>
      messages.where((m) => m['type'] == 'action').toList();

  List<Map<String, Object?>> get countdowns => messages
      .where((m) => m['type'] == 'countdown' || m['type'] == 'countdownCancel')
      .toList();

  /// id задания → принято штук (как очередь мода: только прирост).
  final Map<String, int> accepted = {};

  /// Сколько раз действие реально выполнено (по всем заданиям).
  int executed = 0;

  /// Присылать промежуточный прогресс перед итогом.
  bool sendProgress = false;

  final Map<String, String> _first = {};
  final Map<String, String> _last = {};

  void _respond(Map<String, Object?> m) {
    final id = m['id'] as String;
    final total = (m['total'] as num?)?.toInt() ?? 1;
    final before = accepted[id] ?? 0;
    final delta = total - before;
    if (delta > 0) {
      accepted[id] = total;
      if (sendProgress && total > 1) {
        send({
          'type': 'actionResult', 'id': id, 'ok': true, 'result': 'Выполнено $before из $total',
          'room': room, 'accepted': total, 'done': before, 'queued': delta, 'finished': false,
        });
      }
      for (var i = 0; i < delta; i++) {
        final text = _runOne(m);
        executed++;
        _first[id] ??= text;
        _last[id] = text;
      }
    }
    final done = accepted[id] ?? 0;
    send({
      'type': 'actionResult', 'id': id, 'ok': true, 'result': _summary(id, done),
      'room': room, 'accepted': done, 'done': done, 'queued': 0, 'finished': true,
    });
    parkour(room: room);
  }

  String _summary(String id, int done) {
    final first = RegExp(r'^Комната (\d+) → (\d+)$').firstMatch(_first[id] ?? '');
    final last = RegExp(r'^Комната (\d+) → (\d+)$').firstMatch(_last[id] ?? '');
    if (first != null && last != null) {
      final text = 'Комната ${first.group(1)} → ${last.group(2)}';
      return done > 1 ? '$text (×$done)' : text;
    }
    final text = _last[id] ?? '';
    return done > 1 ? '$text ×$done' : text;
  }

  String _runOne(Map<String, Object?> m) {
    final params = (m['params'] as Map?)?.cast<String, Object?>() ?? const {};
    final rooms = (params['rooms'] as num?)?.toInt() ?? 1;
    final from = room;
    switch (m['action']) {
      case 'room_back':
        room = (room - rooms).clamp(1, 100).toInt();
        return 'Комната $from → $room';
      case 'room_forward':
        room = (room + rooms).clamp(1, 100).toInt();
        return 'Комната $from → $room';
      case 'to_first_level':
        room = 1;
        return 'Комната $from → 1';
      case 'to_last_level':
        room = 100;
        return 'Комната $from → 100';
      case 'goto_room':
        room = ((params['room'] as num?)?.toInt() ?? room).clamp(1, 100).toInt();
        return 'Комната $from → $room';
      case 'push':
        return 'Толчок ${_dir(params['direction'] ?? 'left')}';
      case 'super_push':
        return 'Суперсильный толчок ${_dir(params['direction'] ?? 'forward')}';
      default:
        return 'Выполнено: ${m['action']}';
    }
  }

  static String _dir(Object? d) => switch (d) {
        'right' => 'вправо',
        'left' => 'влево',
        'back' => 'назад',
        _ => 'вперёд',
      };

  /// Мод 2.0: умеет действия, мир открыт, карта на месте.
  void helloParkour({int room = 12}) {
    this.room = room;
    send({
      'type': 'hello',
      'protocol': 2,
      'modVersion': '2.1.0',
      'minecraftVersion': '1.21.1',
      'worldReady': true,
      'parkourActions': true,
      'actionQueue': true,
    });
    parkour(room: room);
  }

  void parkour({required int room, bool available = true}) => send({
        'type': 'parkour',
        'available': available,
        'room': room,
        'finished': false,
        'falls': 0,
        'seconds': 0,
        'roomFalls': 0,
        'bestRoom': room,
      });

  static Future<FakeMod> connect(int port) async => FakeMod._(
      await WebSocket.connect('ws://127.0.0.1:$port/dirronlive'));

  final WebSocket socket;
  final List<Map<String, Object?>> messages = [];
  bool closed = false;

  List<Map<String, Object?>> get gifts =>
      messages.where((m) => m['type'] == 'gift').toList();

  void send(Map<String, Object?> message) => socket.add(jsonEncode(message));

  void hello({required bool worldReady}) => send({
        'type': 'hello',
        'protocol': 1,
        'modVersion': '1.0.0',
        'minecraftVersion': '1.21.1',
        'worldReady': worldReady,
      });

  void world(bool ready) => send({'type': 'world', 'worldReady': ready});

  void ack(String id) => send({'type': 'ack', 'id': id});

  Future<void> close() => socket.close();
}

/// Ждёт условия до 5 секунд.
Future<void> waitFor(bool Function() condition, {String? reason}) async {
  final stopwatch = Stopwatch()..start();
  while (!condition()) {
    if (stopwatch.elapsed > const Duration(seconds: 5)) {
      fail('Не дождались: ${reason ?? 'условие'}');
    }
    await Future<void>.delayed(const Duration(milliseconds: 10));
  }
}



import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../features/modes/modes_catalog.dart';
import '../../features/parkour/parkour_rules.dart';
import 'parkour/parkour_screen.dart';
import '../theme/app_colors.dart';
import '../widgets/common.dart';

/// Каталог мини-игр в виде сетки карточек; готовый режим открывается
/// своим экраном (паркур — правила «подарок → действие»).
class ModesScreen extends ConsumerWidget {
  const ModesScreen({super.key});

  static IconData _iconFor(String id) => switch (id) {
        'dirron_parkour_100' => Icons.directions_run_rounded,
        'maze_escape' => Icons.grid_4x4_rounded,
        'evolution_chaos' => Icons.auto_awesome_rounded,
        _ => Icons.sports_esports_rounded,
      };

  static Color _stageColor(ModeStage stage) => switch (stage) {
        ModeStage.planned => AppColors.accentAlt,
        ModeStage.inDevelopment => AppColors.warning,
        ModeStage.ready => AppColors.success,
      };

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final open = ref.watch(openModeProvider);
    if (open == parkourModeId) return const ParkourScreen();
    final parkourActive = ref.watch(parkourRulesProvider).modeActive;
    final parkourRules = ref.watch(parkourRulesProvider).rules.length;
    return SectionPage(
      title: 'Режимы',
      subtitle: 'Мини-игры, которыми управляют подарки зрителей',
      children: [
        LayoutBuilder(
          builder: (context, constraints) {
            const spacing = 16.0;
            final width = constraints.maxWidth;
            final columns = width >= 900 ? 3 : (width >= 560 ? 2 : 1);
            final cardWidth =
                ((width - spacing * (columns - 1)) / columns).floorToDouble();
            return Wrap(
              spacing: spacing,
              runSpacing: spacing,
              children: [
                for (final mode in gameModes)
                  SizedBox(
                    width: cardWidth,
                    child: _ModeCard(
                      key: ValueKey('mode-${mode.id}'),
                      mode: mode,
                      icon: _iconFor(mode.id),
                      stageColor: _stageColor(mode.stage),
                      status: mode.id == parkourModeId
                          ? '${parkourActive ? 'Режим активен' : 'Режим выключен'} · правил: $parkourRules'
                          : null,
                      onOpen: mode.stage == ModeStage.ready
                          ? () => ref.read(openModeProvider.notifier).open(mode.id)
                          : null,
                    ),
                  ),
              ],
            );
          },
        ),
      ],
    );
  }
}

class _ModeCard extends StatelessWidget {
  const _ModeCard({
    super.key,
    required this.mode,
    required this.icon,
    required this.stageColor,
    this.status,
    this.onOpen,
  });

  final GameModeInfo mode;
  final IconData icon;
  final Color stageColor;
  final String? status;
  final VoidCallback? onOpen;

  @override
  Widget build(BuildContext context) {
    return Panel(
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              IconBadge(icon: icon, size: 48),
              const Spacer(),
              TagChip(label: mode.stage.label, color: stageColor),
            ],
          ),
          const SizedBox(height: 16),
          Text(
            mode.title,
            style: const TextStyle(
              fontSize: 18,
              fontWeight: FontWeight.w700,
              color: AppColors.text,
            ),
          ),
          const SizedBox(height: 8),
          Text(
            mode.description,
            style: const TextStyle(
              fontSize: 14,
              height: 1.4,
              color: AppColors.textMuted,
            ),
          ),
          if (status != null) ...[
            const SizedBox(height: 10),
            Text(
              status!,
              style: const TextStyle(fontSize: 13, color: AppColors.textFaint),
            ),
          ],
          if (onOpen != null) ...[
            const SizedBox(height: 16),
            FilledButton.icon(
              key: ValueKey('open-${mode.id}'),
              onPressed: onOpen,
              icon: const Icon(Icons.tune_rounded, size: 18),
              label: const Text('Открыть и настроить'),
            ),
          ],
        ],
      ),
    );
  }
}

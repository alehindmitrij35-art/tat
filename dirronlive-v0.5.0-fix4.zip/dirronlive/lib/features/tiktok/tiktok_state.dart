/// Фактическое состояние подключения к эфиру TikTok LIVE.
enum TikTokPhase {
  off('Не подключено'),
  connecting('Подключение…'),
  connected('Подключено'),
  offline('Эфир не найден'),
  reconnecting('Переподключение…'),
  ended('Эфир завершён'),
  networkError('Ошибка сети'),
  serviceError('Ошибка сервиса');

  const TikTokPhase(this.label);

  final String label;
}

class TikTokState {
  const TikTokState({
    this.phase = TikTokPhase.off,
    this.uniqueId,
    this.message,
    this.retryIn,
    this.attempt = 0,
  });

  final TikTokPhase phase;

  /// Ник, к эфиру которого подключаемся (без @).
  final String? uniqueId;

  /// Пояснение: причина ошибки, что делать дальше.
  final String? message;

  /// Через сколько будет следующая попытка переподключения.
  final Duration? retryIn;

  /// Номер попытки переподключения (с 1).
  final int attempt;

  /// Одинаковый текст статуса для «Эфира» и настроек.
  String get label {
    if (phase == TikTokPhase.reconnecting && retryIn != null) {
      return 'Переподключение через ${retryIn!.inSeconds} с';
    }
    return phase.label;
  }

  /// Пользователь нажал «Подключиться», и попытки идут.
  bool get isActive =>
      phase == TikTokPhase.connecting ||
      phase == TikTokPhase.connected ||
      phase == TikTokPhase.reconnecting;

  /// Показать кнопку «Повторить».
  bool get canRetry =>
      phase == TikTokPhase.offline ||
      phase == TikTokPhase.networkError ||
      phase == TikTokPhase.serviceError ||
      phase == TikTokPhase.ended;
}

import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../core/providers.dart';
import '../../core/storage/json_store.dart';
import 'overlay_kind.dart';

/// Настройки оверлеев: по одному набору значений на оверлей и общие.
class OverlaySettings {
  const OverlaySettings({
    this.byKind = const {},
    this.testMode = false,
    this.streamerName = 'Dirron',
    this.port = 8777,
  });

  /// slug → настройки оверлея.
  final Map<String, Map<String, Object?>> byKind;

  /// Оверлеи показывают тестовые данные (отдельно от эфира).
  final bool testMode;

  /// Имя стримера в фразах: «Mira отправляет Dirron на уровень 1».
  final String streamerName;
  final int port;

  Map<String, Object?> of(OverlayKind kind) => byKind[kind.slug] ?? const {};

  T get<T>(OverlayKind kind, String key, T fallback) {
    final v = of(kind)[key];
    if (v is T) return v;
    if (fallback is int && v is num) return v.toInt() as T;
    if (fallback is double && v is num) return v.toDouble() as T;
    return fallback;
  }

  OverlaySettings copyWith({
    Map<String, Map<String, Object?>>? byKind,
    bool? testMode,
    String? streamerName,
  }) =>
      OverlaySettings(
        byKind: byKind ?? this.byKind,
        testMode: testMode ?? this.testMode,
        streamerName: streamerName ?? this.streamerName,
        port: port,
      );

  Map<String, Object?> toJson() => {
        'version': 1,
        'testMode': testMode,
        'streamerName': streamerName,
        'port': port,
        'overlays': byKind,
      };

  static OverlaySettings fromJson(Map<String, Object?>? json) {
    if (json == null) return const OverlaySettings();
    final raw = json['overlays'];
    final byKind = <String, Map<String, Object?>>{};
    if (raw is Map) {
      raw.forEach((k, v) {
        if (k is String && v is Map) byKind[k] = v.cast<String, Object?>();
      });
    }
    final name = json['streamerName'];
    final port = json['port'];
    return OverlaySettings(
      byKind: byKind,
      testMode: json['testMode'] == true,
      streamerName: name is String && name.trim().isNotEmpty ? name.trim() : 'Dirron',
      port: port is int && port > 1024 && port < 65536 ? port : 8777,
    );
  }
}

class OverlaySettingsRepository {
  OverlaySettingsRepository(this.store);

  static const fileName = 'overlays.json';
  final JsonStore store;

  Future<OverlaySettings> load() async {
    try {
      return OverlaySettings.fromJson(await store.read(fileName));
    } catch (_) {
      return const OverlaySettings();
    }
  }

  Future<void> save(OverlaySettings s) => store.write(fileName, s.toJson());
}

final initialOverlaySettingsProvider = Provider<OverlaySettings>((ref) => const OverlaySettings());

final overlaySettingsProvider =
    NotifierProvider<OverlaySettingsController, OverlaySettings>(OverlaySettingsController.new);

class OverlaySettingsController extends Notifier<OverlaySettings> {
  Future<void> _pending = Future<void>.value();

  @override
  OverlaySettings build() => ref.read(initialOverlaySettingsProvider);

  Future<void> set(OverlayKind kind, String key, Object? value) => update(kind, {key: value});

  Future<void> update(OverlayKind kind, Map<String, Object?> values) {
    final next = {...state.byKind};
    next[kind.slug] = {...state.of(kind), ...values};
    return _save(state.copyWith(byKind: next));
  }

  Future<void> setTestMode(bool on) => _save(state.copyWith(testMode: on));

  Future<void> setStreamerName(String name) =>
      _save(state.copyWith(streamerName: name.trim().isEmpty ? 'Dirron' : name.trim()));

  Future<void> _save(OverlaySettings next) {
    state = next;
    final repo = OverlaySettingsRepository(ref.read(jsonStoreProvider));
    _pending = _pending.then((_) => repo.save(state)).catchError((_) {});
    return _pending;
  }
}

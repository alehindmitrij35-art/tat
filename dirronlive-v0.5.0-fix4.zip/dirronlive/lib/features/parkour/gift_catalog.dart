import 'dart:async';
import 'dart:convert';
import 'dart:io';

import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../core/providers.dart';
import '../../core/storage/json_store.dart';
import '../../core/storage/storage_exception.dart';
import '../../core/events/gift_event.dart';
import '../settings/settings_controller.dart';
import '../tiktok/connector_backend.dart';
import '../tiktok/gift_aggregator.dart';
import '../tiktok/tiktok_controller.dart';
import 'parkour_rules.dart';

/// Подарок из каталога эфира TikTok.
class CatalogGift {
  const CatalogGift({
    required this.id,
    required this.name,
    this.diamonds = 0,
    this.imageUrl,
  });

  final String id;

  /// Название как в TikTok («Rose»).
  final String name;
  final int diamonds;
  final String? imageUrl;

  /// Название в Dirronlive («Роза»).
  String get displayName => translateGiftName(name);

  Map<String, Object?> toJson() => {
        'id': id,
        'name': name,
        'diamonds': diamonds,
        if (imageUrl != null) 'image': imageUrl,
      };

  static CatalogGift? fromJson(Object? json) {
    if (json is! Map) return null;
    final id = json['id'];
    final name = json['name'];
    if (id == null || name is! String || name.trim().isEmpty) return null;
    final idText = '$id'.trim();
    if (idText.isEmpty || idText == '0') return null;
    final diamonds = json['diamonds'] ?? json['diamond_count'];
    final image = json['image'];
    return CatalogGift(
      id: idText,
      name: name.trim(),
      diamonds: diamonds is num ? diamonds.toInt() : 0,
      imageUrl: image is String && image.startsWith('http') ? image : null,
    );
  }

  /// Поиск по названию (русскому и английскому). ID подарка — внутренний,
  /// в программе не показывается.
  bool matchesQuery(String query) {
    final q = query.trim().toLowerCase();
    if (q.isEmpty) return true;
    return name.toLowerCase().contains(q) || displayName.toLowerCase().contains(q);
  }
}

/// Сохранённый каталог подарков эфира.
class GiftCatalog {
  const GiftCatalog({
    this.gifts = const [],
    this.fetchedAt,
    this.streamer,
    this.seen = const [],
  });

  /// Каталог эфира от коннектора (последний успешный).
  final List<CatalogGift> gifts;
  final DateTime? fetchedAt;
  final String? streamer;

  /// Подарки, которые уже приходили в эфирах (с картинкой и ценой).
  final List<CatalogGift> seen;

  bool get isEmpty => gifts.isEmpty;

  /// Каталога от коннектора нет, есть только полученные в эфире подарки.
  bool get onlySeen => gifts.isEmpty && seen.isNotEmpty;

  /// Всё, из чего можно выбирать: каталог плюс полученные в эфире.
  List<CatalogGift> get selectable {
    if (gifts.isEmpty) return seen;
    final ids = {for (final g in gifts) g.id};
    return [...gifts, for (final g in seen) if (!ids.contains(g.id)) g];
  }

  GiftCatalog withSeen(List<CatalogGift> seen) =>
      GiftCatalog(gifts: gifts, fetchedAt: fetchedAt, streamer: streamer, seen: seen);

  Set<String> get ids => {for (final g in gifts) g.id};

  CatalogGift? byId(String id) {
    for (final g in gifts) {
      if (g.id == id) return g;
    }
    for (final g in seen) {
      if (g.id == id) return g;
    }
    return null;
  }

  Map<String, Object?> toJson() => {
        'version': 1,
        if (fetchedAt != null) 'fetchedAt': fetchedAt!.toUtc().toIso8601String(),
        if (streamer != null) 'streamer': streamer,
        'gifts': [for (final g in gifts) g.toJson()],
        'seen': [for (final g in seen) g.toJson()],
      };

  static GiftCatalog fromJson(Map<String, Object?> json) {
    final raw = json['gifts'];
    final rawSeen = json['seen'];
    final fetched = json['fetchedAt'];
    final streamer = json['streamer'];
    return GiftCatalog(
      seen: [
        if (rawSeen is List)
          for (final item in rawSeen)
            if (CatalogGift.fromJson(item) case final CatalogGift g) g,
      ],
      gifts: [
        if (raw is List)
          for (final item in raw)
            if (CatalogGift.fromJson(item) case final CatalogGift g) g,
      ],
      fetchedAt: fetched is String ? DateTime.tryParse(fetched)?.toLocal() : null,
      streamer: streamer is String && streamer.isNotEmpty ? streamer : null,
    );
  }
}

class GiftCatalogRepository {
  GiftCatalogRepository(this.store);

  static const fileName = 'gift_catalog.json';

  final JsonStore store;

  /// Читает каталог. Бросает [StorageException] / [FormatException].
  Future<GiftCatalog> read() async {
    final json = await store.read(fileName);
    return json == null ? const GiftCatalog() : GiftCatalog.fromJson(json);
  }

  Future<GiftCatalog> load() async {
    try {
      return await read();
    } catch (_) {
      return const GiftCatalog();
    }
  }

  Future<void> save(GiftCatalog catalog) => store.write(fileName, catalog.toJson());
}

/// Ошибка получения каталога: `network` — сеть, `offline` — эфир не найден,
/// `service` — TikTok или сервер подписи.
class CatalogFetchException implements Exception {
  const CatalogFetchException(this.kind, this.message);

  final String kind;
  final String message;

  @override
  String toString() => message;
}

abstract interface class GiftCatalogFetcher {
  /// Полный список подарков TikTok (эфир не нужен). [uniqueId] — запасной
  /// путь через эфир этого ника. Бросает [CatalogFetchException].
  Future<List<CatalogGift>> fetch({String? uniqueId, String? apiKey});
}

/// Запускает коннектор с `--fetch-gifts` и читает ответ.
class NodeGiftCatalogFetcher implements GiftCatalogFetcher {
  NodeGiftCatalogFetcher({this.location, this.environment, this.timeout = const Duration(seconds: 40)});

  final ConnectorLocation? location;
  final Map<String, String>? environment;
  final Duration timeout;

  @override
  Future<List<CatalogGift>> fetch({String? uniqueId, String? apiKey}) async {
    final where = location ?? ConnectorLocation.resolve();
    if (where == null) {
      throw const CatalogFetchException(
          'service', 'Коннектор TikTok не найден рядом с программой. Переустановите Dirronlive.');
    }
    final ProcessResult result;
    try {
      result = await Process.run(
        where.node,
        [
          where.script,
          '--fetch-gifts',
          '--lang',
          'ru-RU',
          if (uniqueId != null && uniqueId.isNotEmpty) ...['--user', uniqueId],
          if (apiKey != null && apiKey.isNotEmpty) ...['--key', apiKey],
        ],
        workingDirectory: where.workingDirectory,
        environment: environment,
        stdoutEncoding: utf8,
        stderrEncoding: utf8,
      ).timeout(timeout);
    } on TimeoutException {
      throw const CatalogFetchException('network', 'TikTok не ответил за 40 секунд.');
    } on ProcessException catch (e) {
      throw CatalogFetchException('service', 'Не удалось запустить коннектор: ${e.message}');
    }
    return parseFetchOutput('${result.stdout}');
  }

  /// Разбирает строки JSON коннектора (вынесено для тестов).
  static List<CatalogGift> parseFetchOutput(String stdout) {
    Map<String, Object?>? gifts;
    Map<String, Object?>? error;
    for (final line in const LineSplitter().convert(stdout)) {
      final text = line.trim();
      if (!text.startsWith('{')) continue;
      try {
        final decoded = jsonDecode(text);
        if (decoded is! Map) continue;
        final map = decoded.cast<String, Object?>();
        if (map['type'] == 'gifts') gifts = map;
        if (map['type'] == 'status' && map['status'] == 'error' ||
            map['type'] == 'status' && map['status'] == 'offline') {
          error = map;
        }
      } on FormatException {
        continue;
      }
    }
    if (gifts != null) {
      final raw = gifts['gifts'];
      return [
        if (raw is List)
          for (final item in raw)
            if (CatalogGift.fromJson(item) case final CatalogGift g) g,
      ];
    }
    if (error != null) {
      final kind = error['status'] == 'offline' ? 'offline' : '${error['kind'] ?? 'service'}';
      throw CatalogFetchException(kind, '${error['message'] ?? 'Ошибка коннектора'}');
    }
    throw const CatalogFetchException('service', 'Коннектор не вернул каталог подарков.');
  }
}

final giftCatalogFetcherProvider =
    Provider<GiftCatalogFetcher>((ref) => NodeGiftCatalogFetcher());

/// Полный список подарков, вшитый в установщик при сборке
/// (`tiktok\gifts-snapshot.json` рядом с коннектором). Показывается, пока
/// программа ни разу не скачала список сама.
final giftSnapshotProvider = Provider<GiftCatalog?>((ref) => readGiftSnapshot());

GiftCatalog? readGiftSnapshot() {
  try {
    final where = ConnectorLocation.resolve();
    if (where == null) return null;
    final file = File('${where.workingDirectory}${Platform.pathSeparator}gifts-snapshot.json');
    if (!file.existsSync()) return null;
    final json = jsonDecode(file.readAsStringSync());
    if (json is! Map) return null;
    final catalog = GiftCatalog.fromJson(json.cast<String, Object?>());
    return catalog.gifts.isEmpty ? null : catalog;
  } catch (_) {
    return null;
  }
}

final initialGiftCatalogProvider = Provider<GiftCatalog>((ref) => const GiftCatalog());

/// Итог «Обновить и проверить каталог».
class CatalogReport {
  const CatalogReport({
    required this.checkedAt,
    required this.fetched,
    this.connectorCount = 0,
    this.savedCount = 0,
    this.editorCount = 0,
    this.missingInSaved = const [],
    this.missingInEditor = const [],
    this.added = const [],
    this.removed = const [],
    this.rulesWithoutGift = const [],
    this.error,
    this.errorKind,
    this.onlySeen = false,
  });

  /// Коннектор отдал только подарки, уже полученные в эфире.
  final bool onlySeen;

  final DateTime checkedAt;

  /// Каталог получен от коннектора в этот раз.
  final bool fetched;
  final int connectorCount;
  final int savedCount;
  final int editorCount;

  /// ID, которые прислал коннектор, но которых нет в сохранённом файле / в редакторе.
  final List<String> missingInSaved;
  final List<String> missingInEditor;

  /// Новые и пропавшие по сравнению с прошлым каталогом.
  final List<String> added;
  final List<String> removed;

  /// Правила, чьих подарков нет в каталоге этого эфира.
  final List<String> rulesWithoutGift;
  final String? error;
  final String? errorKind;

  /// Все три набора совпали — только тогда можно писать «все доступны».
  bool get allAvailable =>
      fetched && error == null && missingInSaved.isEmpty && missingInEditor.isEmpty &&
      connectorCount == savedCount && savedCount == editorCount && connectorCount > 0;
}

class GiftCatalogState {
  const GiftCatalogState({
    this.catalog = const GiftCatalog(),
    this.busy = false,
    this.report,
  });

  /// То, что видно в редакторе правил.
  final GiftCatalog catalog;
  final bool busy;
  final CatalogReport? report;
}

final giftCatalogProvider =
    NotifierProvider<GiftCatalogController, GiftCatalogState>(GiftCatalogController.new);

class GiftCatalogController extends Notifier<GiftCatalogState> {
  @override
  GiftCatalogState build() {
    ref.onDispose(() => _seenSave?.cancel());
    final saved = ref.read(initialGiftCatalogProvider);
    if (saved.gifts.isEmpty) {
      final snapshot = ref.read(giftSnapshotProvider);
      if (snapshot != null) {
        _fromSnapshot = true;
        return GiftCatalogState(
          // Без даты: в окне каталога видно, что это список из установщика.
          catalog: GiftCatalog(gifts: _sorted(snapshot.gifts), seen: saved.seen),
        );
      }
    }
    return GiftCatalogState(catalog: saved);
  }

  /// Сейчас показан список из установщика — его надо обновить со своего компьютера.
  bool _fromSnapshot = false;

  static List<CatalogGift> _sorted(List<CatalogGift> gifts) {
    final unique = <String, CatalogGift>{for (final g in gifts) g.id: g};
    return unique.values.toList()
      ..sort((a, b) => a.diamonds != b.diamonds ? a.diamonds.compareTo(b.diamonds) : a.name.compareTo(b.name));
  }

  /// При запуске программы: скачать свежий полный список подарков TikTok,
  /// если его ещё нет, он из установщика или старше [maxAge]. Эфир не нужен.
  Future<void> autoSync({Duration maxAge = const Duration(hours: 12)}) async {
    final catalog = state.catalog;
    final fetchedAt = catalog.fetchedAt;
    final fresh = !_fromSnapshot &&
        catalog.gifts.isNotEmpty &&
        fetchedAt != null &&
        ref.read(clockProvider)().difference(fetchedAt) < maxAge;
    if (fresh) return;
    await refreshAndCheck();
  }

  bool knows(String giftId) => state.catalog.byId(giftId) != null;

  /// Нет сохранённого каталога эфира — тогда «неизвестных» подарков не бывает.
  bool knowsOrEmpty(String giftId) =>
      state.catalog.gifts.isEmpty || state.catalog.gifts.any((g) => g.id == giftId);

  Timer? _seenSave;

  /// Подарок пришёл в эфире: запомнить его картинку и цену.
  void noteSeen(GiftEvent record) {
    final id = record.giftId;
    if (id == null) return;
    final catalog = state.catalog;
    final existing = catalog.seen.where((g) => g.id == id).firstOrNull;
    if (existing != null && (existing.imageUrl != null || record.giftImage == null)) return;
    final gift = CatalogGift(
      id: id,
      name: record.giftName,
      diamonds: record.diamonds,
      imageUrl: record.giftImage,
    );
    final seen = [for (final g in catalog.seen) if (g.id != id) g, gift];
    state = GiftCatalogState(catalog: catalog.withSeen(seen), busy: state.busy, report: state.report);
    _seenSave?.cancel();
    _seenSave = Timer(const Duration(seconds: 2), () {
      unawaited(GiftCatalogRepository(ref.read(jsonStoreProvider)).save(state.catalog).catchError((_) {}));
    });
  }

  /// Получить каталог у коннектора, сохранить, перечитать с диска и сверить
  /// три набора ID: коннектор, файл и редактор.
  Future<CatalogReport> refreshAndCheck() async {
    if (state.busy) return state.report ?? CatalogReport(checkedAt: DateTime.now(), fetched: false);
    final clock = ref.read(clockProvider);
    final previous = state.catalog;
    final nickname = ref.read(settingsProvider).tiktokNickname.trim().replaceFirst('@', '');
    state = GiftCatalogState(catalog: previous, busy: true, report: state.report);

    CatalogReport finish(CatalogReport report) {
      state = GiftCatalogState(catalog: state.catalog, report: report);
      return report;
    }

    // Ник не обязателен: полный список TikTok скачивается без эфира.
    List<CatalogGift> fetched;
    try {
      // Идёт эфир — каталог берём у того же подключения (у отдельного
      // процесса без подключения TikTok часто не отдаёт список комнаты).
      final wait = Completer<Object>();
      _liveWait = wait;
      if (ref.read(tiktokProvider.notifier).requestGifts()) {
        final got = await wait.future.timeout(const Duration(seconds: 45),
            onTimeout: () => const CatalogFetchException('network', 'Коннектор не прислал каталог за 45 секунд.'));
        if (got is CatalogFetchException) throw got;
        fetched = got as List<CatalogGift>;
      } else {
        _liveWait = null;
        fetched = await ref.read(giftCatalogFetcherProvider).fetch(
              uniqueId: nickname.isEmpty ? null : nickname,
              apiKey: ref.read(settingsProvider).eulerApiKey,
            );
      }
    } on CatalogFetchException catch (e) {
      _liveWait = null;
      return finish(CatalogReport(
        checkedAt: clock(),
        fetched: false,
        savedCount: previous.gifts.length,
        editorCount: previous.gifts.length,
        error: e.message,
        errorKind: e.kind,
      ));
    }
    _liveWait = null;
    return _apply(fetched, nickname, previous);
  }

  Completer<Object>? _liveWait;

  /// Каталог от текущего подключения к эфиру: ответ на «Обновить каталог»
  /// или сам после подключения (тогда сохраняется и сверяется сразу).
  Future<void> acceptFromConnector(List<Object?> raw, {required String streamer, String how = ''}) async {
    final gifts = [
      for (final item in raw)
        if (CatalogGift.fromJson(item) case final CatalogGift g) g,
    ];
    final wait = _liveWait;
    if (wait != null && !wait.isCompleted) {
      wait.complete(gifts);
      return;
    }
    if (state.busy || gifts.isEmpty) return;
    final previous = state.catalog;
    state = GiftCatalogState(catalog: previous, busy: true, report: state.report);
    await _apply(gifts, streamer.trim().replaceFirst('@', ''), previous);
  }

  /// Коннектор не смог получить каталог: причина со всеми попытками.
  void connectorFailed({required String kind, required String message, List<String> attempts = const []}) {
    final text = attempts.isEmpty ? message : '$message Попытки: ${attempts.join('; ')}.';
    final wait = _liveWait;
    if (wait != null && !wait.isCompleted) {
      wait.complete(CatalogFetchException(kind, text));
      return;
    }
    if (state.busy) return;
    final catalog = state.catalog;
    state = GiftCatalogState(
      catalog: catalog,
      report: CatalogReport(
        checkedAt: ref.read(clockProvider)(),
        fetched: false,
        savedCount: catalog.gifts.length,
        editorCount: catalog.gifts.length,
        error: text,
        errorKind: kind,
      ),
    );
  }

  /// Сохранить полученный каталог, перечитать с диска и сверить три
  /// набора ID: коннектор, файл и доступные для выбора.
  Future<CatalogReport> _apply(List<CatalogGift> fetched, String nickname, GiftCatalog previous) async {
    final clock = ref.read(clockProvider);
    CatalogReport finish(CatalogReport report) {
      state = GiftCatalogState(catalog: state.catalog, report: report);
      return report;
    }

    if (fetched.isEmpty) {
      return finish(CatalogReport(
        checkedAt: clock(),
        fetched: false,
        savedCount: previous.gifts.length,
        editorCount: previous.gifts.length,
        error: 'TikTok вернул пустой каталог подарков.',
        errorKind: 'service',
      ));
    }

    // Без повторов ID, в порядке стоимости.
    final unique = <String, CatalogGift>{for (final g in fetched) g.id: g};
    final gifts = _sorted(fetched);
    _fromSnapshot = false;
    final next = GiftCatalog(
        gifts: gifts, fetchedAt: clock(), streamer: nickname.isEmpty ? null : nickname, seen: previous.seen);
    final seenIds = {for (final g in previous.seen) g.id};
    final onlySeen = seenIds.isNotEmpty && unique.keys.every(seenIds.contains) && unique.length <= seenIds.length;
    final repository = GiftCatalogRepository(ref.read(jsonStoreProvider));

    GiftCatalog saved;
    String? saveError;
    try {
      await repository.save(next);
      saved = await repository.read();
    } catch (e) {
      saveError = 'Каталог получен, но не сохранён: ${e is StorageException ? e.message : e}';
      saved = const GiftCatalog();
    }

    // Редактор показывает то, что прочитано с диска (а если не записалось —
    // полученный каталог, чтобы им можно было пользоваться сейчас).
    final editor = saveError == null ? saved : next;
    state = GiftCatalogState(catalog: editor, busy: true, report: state.report);
    final editorIds = state.catalog.ids;

    final connectorIds = unique.keys.toSet();
    final savedIds = saved.ids;
    String label(String id) {
      final g = unique[id] ?? previous.byId(id);
      // ID подарка — внутренний: в отчёте только название и цена.
      if (g == null) return 'подарок без названия';
      return g.diamonds > 0 ? '${g.displayName} (${g.diamonds} мон.)' : g.displayName;
    }

    final rules = ref.read(parkourRulesProvider).rules;
    await ref.read(parkourRulesProvider.notifier).fillGiftIds({
      for (final g in gifts) g.displayName.toLowerCase(): (id: g.id, image: g.imageUrl),
      for (final g in gifts) g.name.toLowerCase(): (id: g.id, image: g.imageUrl),
    });

    return finish(CatalogReport(
      checkedAt: clock(),
      fetched: true,
      connectorCount: connectorIds.length,
      savedCount: savedIds.length,
      editorCount: editorIds.length,
      missingInSaved: [for (final id in connectorIds) if (!savedIds.contains(id)) label(id)],
      missingInEditor: [for (final id in connectorIds) if (!editorIds.contains(id)) label(id)],
      added: previous.isEmpty
          ? const []
          : [for (final id in connectorIds) if (!previous.ids.contains(id)) label(id)],
      removed: [for (final id in previous.ids) if (!connectorIds.contains(id)) label(id)],
      rulesWithoutGift: [
        for (final r in rules)
          if (r.giftId != null && !connectorIds.contains(r.giftId))
            '${r.giftName} → ${r.actionTitle}',
      ],
      error: saveError,
      errorKind: saveError == null ? null : 'storage',
      onlySeen: onlySeen,
    ));
  }
}

/// Подарки, которые можно выбрать без каталога: популярные, только по названию.
const starterGiftNames = <String>[
  'Роза',
  'Сердечко',
  'Сердце',
  'Сердце руками',
  'Пончик',
  'Мороженое',
  'Духи',
  'Очки',
  'Корги',
  'Лев',
  'Ракета',
  'Галактика',
  'Вселенная',
];

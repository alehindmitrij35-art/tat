import '../features/events/event_history_repository.dart';
import '../features/overlays/overlay_settings.dart';
import '../features/overlays/stream_stats.dart';
import '../features/parkour/gift_catalog.dart';
import '../features/parkour/parkour_rules.dart';
import '../features/settings/app_settings.dart';
import '../features/settings/settings_repository.dart';
import 'events/gift_event.dart';
import 'storage/json_store.dart';

/// Всё, что читается с диска до показа первого окна.
class InitialData {
  const InitialData({
    required this.store,
    required this.history,
    required this.settings,
    this.warnings = const [],
    this.parkourRules = const ParkourRulesState(),
    this.giftCatalog = const GiftCatalog(),
    this.overlaySettings = const OverlaySettings(),
    this.liveStats,
  });

  /// Настройки оверлеев.
  final OverlaySettings overlaySettings;

  /// Статистика эфира с прошлого запуска (тот же эфир не считается дважды).
  final StatsBucket? liveStats;

  /// Правила «подарок → действие» карты Dirron Parkour.
  final ParkourRulesState parkourRules;

  /// Сохранённый каталог подарков эфира.
  final GiftCatalog giftCatalog;

  final JsonStore store;

  /// Сохранённые события, новые сверху.
  final List<GiftEvent> history;
  final AppSettings settings;

  /// Сообщения для пользователя о проблемах при загрузке.
  final List<String> warnings;
}

Future<InitialData> loadInitialData(JsonStore store) async {
  final history = await EventHistoryRepository(store).load();
  final settings = await SettingsRepository(store).load();
  final (rules, ruleWarnings) = await ParkourRulesRepository(store).load();
  final catalog = await GiftCatalogRepository(store).load();
  final overlays = await OverlaySettingsRepository(store).load();
  final liveStats = await loadLiveStats(store);
  return InitialData(
    store: store,
    history: history.events,
    settings: settings.settings,
    warnings: [...history.warnings, ...settings.warnings, ...ruleWarnings],
    parkourRules: rules,
    giftCatalog: catalog,
    overlaySettings: overlays,
    liveStats: liveStats,
  );
}
